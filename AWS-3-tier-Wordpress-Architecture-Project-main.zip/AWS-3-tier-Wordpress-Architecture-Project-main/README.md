# AWS-3-tier-Wordpress-Architecture-Project
Configuration Files for the AWS 3-tier Wordpress Architecture Project
https://www.youtube.com/watch?v=2iymYCAZR6Y&list=PLMuRUTNfNL4oHVAS1kYEjU338J7I8oDPJ
