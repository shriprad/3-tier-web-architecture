# Show server IP in php ->
 
<?php 
 
$ip_server = $_SERVER['SERVER_ADDR']; 
  
echo "Server IP Address is: $ip_server"; 
  
?>
 
